const themeMap = {
  'default': {
    'background-color': 'white',
    'text-color': '#222',
    'highlight-color': '#eee'
  },
  'dark': {
    'background-color': '#222',
    'text-color': 'white',
    'highlight-color': '#2e2e2e'
  }
}
